*warning this project is discontinued (only php, [nodjs is continue](../../../../quad-b/lottsanook-nodejs))

# ล็อตสนุก
เป็นการดึงผลสลากกินแบ่งรัฐบาลจากเว็บ sanook.com และ myhora.com มาเก็บไว้เป็นแบบ json โดยใช้ PHP ในการเขียน

# ลิงค์ API สำหรับผู้พัฒนา

[![Join API](https://files.readme.io/7002e7f-c563a12-rapidapi-badge-dark.png)](https://rapidapi.com/boyphongsakorn/api/thai-lottery1)

# Warning

ถ้าคุณต้องการช่วยเราในการแก้ไขบัค หรือ เพิ่มฟังก์ชั่น ได้โปรดส่งคำขอไปยังที่ [lottsanook-nodejs](../../../../quad-b/lottsanook-nodejs) สำหรับ NodeJS หรือ [lottsanook](../../../../quad-b/lottsanook) สำหรับ PHP

[![GitHub pull requests](https://img.shields.io/github/issues-pr-raw/Quad-B/lottsanook-nodejs?label=Pull%20request%20for%20helped&logo=github)](../../../../quad-b/lottsanook-nodejs) [![GitHub pull requests](https://img.shields.io/github/issues-pr-raw/Quad-B/lottsanook?label=Pull%20request%20for%20helped&logo=github)](../../../../quad-b/lottsanook)
