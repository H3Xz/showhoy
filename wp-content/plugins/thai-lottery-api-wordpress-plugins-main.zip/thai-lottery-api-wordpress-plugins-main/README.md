   Plugin Name: Thai Lottery API
   Plugin URI: https://krupreecha.com/wpplugins
   description: Show results of Thai government lottery.
   Version: 1.0
   Author: krupreecha.com
   Author URI: https://www.krupreecha.com
   License: GPL2