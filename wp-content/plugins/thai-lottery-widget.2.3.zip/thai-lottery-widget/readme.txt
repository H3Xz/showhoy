﻿=== Thai Lottery Widget ===
Contributors: siamlottery
Tags: lottery,lotto,Thai Lottery, Lottery widget, ตรวจหวย , โค้ดตรวจหวยภาษาไทย, glo, หวย,ผลสลากกินแบ่งรัฐบาล, ตรวจสลากกินแบ่งรัฐบาล,สลากกินแบ่งรัฐบาล, สำนักงานสลากกินแบ่งรัฐบาล
Requires at least: 4.0
Tested up to: 5.9
Stable tag: 2.3
Requires PHP: 5.6
Donate link: https://www.lottery.co.th/code
License: GPLv2 or later

แสดงผลสลากกินแบ่งรัฐบาลไทย โค้ดตรวจหวย

== Description ==
Thai Lottery Widget: แสดงผลสลากกินแบ่งรัฐบาลไทย พร้อมระบบตรวจหวย [รายละเอียดอื่นๆ](https://www.lottery.co.th/code)

 ติดตามผ่าน[LINE@](https://page.line.me/oer1981h) หรือ [LINE@](https://page.line.me/gnm7628z) 

Code ตรวจหวยตัวล่าสุด บริการโค้ดตรวจสลากกินแบ่งรัฐบาล iframe api อัพเดทหวยรวดเร็ว ใช้งานง่าย ทั้งเว็บไซต์และบล็อก Responsive รองรับมือถือ

Widget ที่จะทำให้เว็บคุณแสดงผลสลากกินแบ่งรัฐบาลงวดล่าสุด พร้อมระบบตรวจหวย

> <strong>*การใช้งาน Shortcode*</strong><br>
[thailottery width="100%" height="650"]<br>
นำโค้ดนี้ไปวางในส่วนของหน้าเพจหรือหน้าเนื้อหาเพื่อแสดงผล <br>
width=ความกว้าง ค่าปกติ 100%<br>
height=ความสูง ค่าปกติ 650 <br>

> การแสดงผลสลากย้อนหลัง สำหรับการแสดงผล 10 งวดล่าสุด ใช้โค้ดดังนี้ <br><strong>[lottofeed]</strong><br/>
<br/>**สำหรับการจำกัดจำนวนงวด ใช้โค้ดดังนี้ <br><strong>[lottofeed numbers="5"]</strong><br/>
นำโค้ดด้านบนนี้ไปวางในส่วนของหน้าเพจหรือหน้าเนื้อหาเพื่อแสดงผล numbers="5" หมายเลข 5 คือจำนวนงวดที่ต้องการให้แสดง<br>

> <strong>*การใช้งาน Shortcode สำหรับเฉพาะสลากกินแบ่งรัฐบาลอย่างเดียว*</strong><br/>
<strong>[thailottery2] หรือปรับแต่งขนาด [thailottery2 width="100%" height="340"]</strong><br/>
นำโค้ดด้านบนนี้ไปวางในส่วนของหน้าเพจหรือหน้าเนื้อหาเพื่อแสดงผล
<br/>width=ความกว้าง ค่าปกติ 100%, height=ความสูง ค่าปกติ 340

> <strong>*การใช้งาน Shortcode สำหรับขนาดเล็กพิเศษ*</strong><br/>
<strong>[thailottery3] หรือปรับแต่งขนาด [thailottery3 width="210" height="290"]</strong><br/>
นำโค้ดด้านบนนี้ไปวางในส่วนของหน้าเพจหรือหน้าเนื้อหาเพื่อแสดงผล
<br/>width=ความกว้าง ค่าปกติ 210 height=ความสูง ค่าปกติ 290

> <strong>*การใช้งาน Shortcode สำหรับเฉพาะช่องตรวจหวย*</strong><br/>
<strong>[thailottery4] หรือปรับแต่งขนาด [thailottery4 width="100%" height="410"]</strong><br/>
นำโค้ดด้านบนนี้ไปวางในส่วนของหน้าเพจหรือหน้าเนื้อหาเพื่อแสดงผล ช่องค้นหา ตรวจสลากกินแบ่งรัฐบาล
<br/>width=ความกว้าง ค่าปกติ 100% height=ความสูง ค่าปกติ 410

> <strong>Bug Reports</strong><br>
> หากพบเห็นข้อผิดพลาดสามารถแจ้งได้ที่ admin@lottery.co.th

= Tags =
Thai Lottery, Lottery widget, ตรวจหวย , โค้ดตรวจหวยภาษาไทย, ผลสลากกินแบ่งรัฐบาล, หวย, หวยรัฐบาล, สำนักงานสลากกินแบ่งรัฐบาล

== Installation ==

Upload the Thai Lottery Widget plugin to your blog, Activate it, then go to Widget are and add to the sidebar. You're done!

การใช้งาน Shortcode
แสดงผลปกติ
[thailottery width="100%" height="650"]
นำโค้ดนี้ไปวางในส่วนของหน้าเพจหรือหน้าเนื้อหาเพื่อแสดงผล 
width=ความกว้าง ค่าปกติ 100%
height=ความสูง ค่าปกติ 650 

การแสดงผลสลากย้อนหลัง
[lottofeed numbers="5"]
นำโค้ดนี้ไปวางในส่วนของหน้าเพจหรือหน้าเนื้อหาเพื่อแสดงผล 
numbers=จำนวนงวดที่ต้องการแสดงผล ค่าปกติอยู่ที่ 10

แสดงผลเฉพาะผลรางวัล
[thailottery2 width="100%" height="340"]
width=ความกว้าง ค่าปกติ 100%
height=ความสูง ค่าปกติ 340

แสดงผลเฉพาะขนาดเล็ก
[thailottery3 width="210" height="290"]
width=ความกว้าง ค่าปกติ 210
height=ความสูง ค่าปกติ 290

สำหรับเฉพาะช่องตรวจหวย
[thailottery4 width="100%" height="410"]
width=ความกว้าง ค่าปกติ 100%
height=ความสูง ค่าปกติ 410

== Changelog ==

= 2.3 =
- Update Disables the block editor widgets

= 2.2 =
- Tested with lastest WordPress Version

= 2.1 =
- Add new Search box lottery to widget and shortcode

= 2.0 =
- Add new shortcode to display more lottery results

= 1.8 =
- Fix bug With constructor method.

= 1.7 =
- Add new Widget for small size.

= 1.6 =
- Compatibility with wordpress 4.9
- Add new Widget to Show only lottery results.

= 1.5 =
- Compatibility with wordpress 4.8 and set 100% for width size.

= 1.4 =
- Compatibility with wordpress 4.7

= 1.3 =
- Add more button to check lottery

= 1.2 =
- Set default to https
- Change style
- Add description in Widget page

= 1.1 =
Add more option and short code available

= 1.0 =
*Release Date - 31 August 2016*

== Frequently Asked Questions == 

การใช้งาน Shortcode
แสดงผลปกติ
[thailottery width="100%" height="650"]
นำโค้ดนี้ไปวางในส่วนของหน้าเพจหรือหน้าเนื้อหาเพื่อแสดงผล 
width=ความกว้าง ค่าปกติ 100%
height=ความสูง ค่าปกติ 650 

การแสดงผลสลากย้อนหลัง
[lottofeed numbers="5"]
นำโค้ดนี้ไปวางในส่วนของหน้าเพจหรือหน้าเนื้อหาเพื่อแสดงผล 
numbers=จำนวนงวดที่ต้องการแสดงผล ค่าปกติอยู่ที่ 10

แสดงผลเฉพาะผลรางวัล
[thailottery2 width="100%" height="340"]
width=ความกว้าง ค่าปกติ 100%
height=ความสูง ค่าปกติ 340

แสดงผลเฉพาะขนาดเล็ก
[thailottery3 width="210" height="290"]
width=ความกว้าง ค่าปกติ 210
height=ความสูง ค่าปกติ 290

สำหรับเฉพาะช่องตรวจหวย
[thailottery4 width="100%" height="410"]
width=ความกว้าง ค่าปกติ 100%
height=ความสูง ค่าปกติ 410

มีข้อสงสัยติดต่อ admin@lottery.co.th

== Upgrade Notice ==

= 2.3 =
- Update Disables the block editor widgets

= 2.2 =
- Tested with lastest WordPress Version

= 2.1 =
- Add new Search box lottery to widget and shortcode

= 2.0 =
- Add new shortcode to display more lottery results

= 1.8 =
- Fix bug With constructor method.

= 1.7 =
- Add new Widget for small size.

= 1.6 =
- Compatibility with wordpress 4.9
- Add new Widget to Show only lottery results.

= 1.5 =
- Compatibility with wordpress 4.8 and set 100% for width size.

= 1.4 =
- Compatibility with wordpress 4.7

= 1.3 =
- Add more button to check lottery

= 1.2 =
- Set default to https
- Change style
- Add description in Widget page

= 1.1 =
Add more option and short code available

= 1.0 =
Show Thai Lottery

== Screenshots ==
1. **Widget-Show** - Show Thai Lottery Widget.
2. **Widget-Editor** - ตั้งค่าการใช้งาน Widget.
3. **Google Mobile Friendly** - 100/100 of Mobile Friendly tested by Google Speedtest.
4. **ThinkwithGoogle Score** - The highest score that we care.
5. **gtmetrix score** - That so fast speed score.
6. **Show only results** - Show only results.
7. **Show results and check numbers** - Show results and check numbers.
8. **Show lottery results with small size** - Show lottery results with small size.